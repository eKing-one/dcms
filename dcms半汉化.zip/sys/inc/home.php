<?
define("H", $_SERVER["DOCUMENT_ROOT"].'/');
$num = 0;
?>