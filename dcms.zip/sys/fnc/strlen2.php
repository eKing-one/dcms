<?
function strlen2($str)
{
	return iconv_strlen($str,"UTF-8");
}
?>