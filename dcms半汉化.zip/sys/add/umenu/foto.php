<?





echo "<img src='/style/my_menu/foto.png' alt='' /> <a href='/foto/$user[id]/'>相片册</a><br />\n";





?>