<?php
if (test_file("inc/icon48/$ras.php"))
{
include "inc/icon48/$ras.php";
}
?>