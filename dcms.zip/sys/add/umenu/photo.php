<?
echo "<img src='/style/my_menu/photo.png' alt='' /> <a href='/photo/$user[id]/'>相片册</a><br />";
?>